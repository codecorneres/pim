<?php $__env->startSection('content'); ?>
<div class="container image-manager">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"><strong>Products</strong>
                    <a class="notify-me" href="<?php echo e(url('/notify')); ?>">Notify me</a>
                </div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <table class="table">
                      <thead>
                        <tr>
                          <th scope="col">#</th>
                          <th scope="col">Title</th>
                          <th scope="col">Product ID</th>
                          <th scope="col">Admin URL</th>
                          <th scope="col">Frontend URL</th>
                          <th scope="col">Has Image ?</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <th scope="row"><?php echo e(++$key); ?></th>
                          <td><?php echo e($product->title); ?></td>
                          <td><?php echo e($product->product_id); ?></td>
                          <td><a href="javascript:void(0)" onclick="window.open('<?php echo e('https://'.env('SHOPIFY_DOMAIN').'/admin/products/'.$product->product_id); ?>');" >Update</a></td>
                          <td><a href="javascript:void(0)" onclick="window.open('<?php echo e('https://'.env('SHOPIFY_DOMAIN').'/products/'.$product->handle); ?>');" >View</a></td>
                          <td><?php echo e($product->image ? 'yes' : 'no'); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>
                    
                </div>
                <div class="card-footer">
                    <div class="pagination"> 
                      <?php echo e($products->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dsdevelo/public_html/demo/product-img-manager/resources/views/home.blade.php ENDPATH**/ ?>